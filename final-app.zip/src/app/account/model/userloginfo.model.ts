export class Userloginfo {
}
