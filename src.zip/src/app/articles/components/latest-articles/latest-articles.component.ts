import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-articles',
  templateUrl: './latest-articles.component.html',
  styleUrls: ['./latest-articles.component.css']
})
export class LatestArticlesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
