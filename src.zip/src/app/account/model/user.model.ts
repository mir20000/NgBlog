
export interface Users {
    id: string,
    name: string,
    email: string,
    mobile: string,
    password: string,
    isAdmin: boolean,
    isActive: boolean,
    join_time: Date,
  }